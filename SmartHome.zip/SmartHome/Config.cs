
namespace SmartHome
{
    public static class Config
    {
        public const string DatabaseName = "smart_home.db";
    }
}
