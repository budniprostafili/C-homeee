
using System;
using System.Data.SQLite;
using SmartHome;

namespace SmartHome.Models
{
    public class Device
    {
        public string Name { get; }
        public bool State { get; set; }

        public Device(string name, bool state)
        {
            Name = name;
            State = state;
        }

        public void Toggle()
        {
            State = !State;
        }

        public void SaveState()
        {
            using (var conn = new SQLiteConnection($"Data Source={Config.DatabaseName}"))
            {
                conn.Open();
                var command = new SQLiteCommand("INSERT OR REPLACE INTO devices (name, state) VALUES (@name, @state)", conn);
                command.Parameters.AddWithValue("@name", Name);
                command.Parameters.AddWithValue("@state", State);
                command.ExecuteNonQuery();
            }
        }

        public override string ToString()
        {
            return $"{Name} is {(State ? "on" : "off")}";
        }
    }
}
