
using System;
using System.Data.SQLite;
using SmartHome;

namespace SmartHome.Models
{
    public class Schedule
    {
        public string DeviceName { get; }
        public string Time { get; }
        public string Action { get; }

        public Schedule(string deviceName, string time, string action)
        {
            DeviceName = deviceName;
            Time = time;
            Action = action;
        }

        public void Save()
        {
            using (var conn = new SQLiteConnection($"Data Source={Config.DatabaseName}"))
            {
                conn.Open();
                var command = new SQLiteCommand("INSERT INTO schedule (device_name, time, action) VALUES (@device_name, @time, @action)", conn);
                command.Parameters.AddWithValue("@device_name", DeviceName);
                command.Parameters.AddWithValue("@time", Time);
                command.Parameters.AddWithValue("@action", Action);
                command.ExecuteNonQuery();
            }
        }

        public override string ToString()
        {
            return $"Schedule for {DeviceName} at {Time} to {Action}";
        }
    }
}
