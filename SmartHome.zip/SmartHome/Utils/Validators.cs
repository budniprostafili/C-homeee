
namespace SmartHome.Utils
{
    public static class Validators
    {
        public static bool ValidateDeviceName(string name)
        {
            return !string.IsNullOrWhiteSpace(name);
        }

        public static bool ValidateTemperature(int temperature)
        {
            return temperature >= 0 && temperature <= 40;
        }
    }
}
