
using System.Net.Http;
using Newtonsoft.Json.Linq;

namespace SmartHome.Services
{
    public class WeatherService
    {
        private readonly string apiKey;
        private readonly string baseUrl = "http://api.weatherapi.com/v1/current.json";

        public WeatherService(string apiKey)
        {
            this.apiKey = apiKey;
        }

        public JObject GetWeather(string location)
        {
            using (var client = new HttpClient())
            {
                var response = client.GetStringAsync($"{baseUrl}?key={apiKey}&q={location}").Result;
                return JObject.Parse(response);
            }
        }
    }
}
