
using System.Data.SQLite;
using SmartHome;

namespace SmartHome.Services
{
    public static class DatabaseService
    {
        public static void SetupDatabase()
        {
            using (var conn = new SQLiteConnection($"Data Source={Config.DatabaseName}"))
            {
                conn.Open();
                var command = new SQLiteCommand(conn);

                command.CommandText = "CREATE TABLE IF NOT EXISTS devices (name TEXT PRIMARY KEY, state BOOLEAN)";
                command.ExecuteNonQuery();

                command.CommandText = "CREATE TABLE IF NOT EXISTS schedule (id INTEGER PRIMARY KEY AUTOINCREMENT, device_name TEXT, time TEXT, action TEXT)";
                command.ExecuteNonQuery();
            }
        }
    }
}
