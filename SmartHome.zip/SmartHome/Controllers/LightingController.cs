
using System;
using System.Collections.Generic;
using System.Linq;
using SmartHome.Models;

namespace SmartHome.Controllers
{
    public class LightingController
    {
        private readonly List<Device> lights;

        public LightingController()
        {
            lights = new List<Device>
            {
                new Device("Living Room Light", false),
                new Device("Kitchen Light", false)
            };
        }

        public void ToggleLight(string lightName)
        {
            var light = lights.FirstOrDefault(l => l.Name == lightName);
            if (light != null)
            {
                light.Toggle();
                light.SaveState();
                Console.WriteLine(light);
            }
            else
            {
                Console.WriteLine($"Light {lightName} not found.");
            }
        }
    }
}
