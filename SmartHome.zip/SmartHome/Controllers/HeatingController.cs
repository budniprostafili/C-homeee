
using System;
using System.Collections.Generic;
using System.Linq;
using SmartHome.Models;

namespace SmartHome.Controllers
{
    public class HeatingController
    {
        private readonly List<Device> heaters;

        public HeatingController()
        {
            heaters = new List<Device>
            {
                new Device("Living Room Heater", false),
                new Device("Bedroom Heater", false)
            };
        }

        public void SetTemperature(string heaterName, int temperature)
        {
            var heater = heaters.FirstOrDefault(h => h.Name == heaterName);
            if (heater != null)
            {
                heater.State = true; // Включить обогреватель
                heater.SaveState();
                Console.WriteLine($"{heaterName} set to {temperature}°C");
            }
            else
            {
                Console.WriteLine($"Heater {heaterName} not found.");
            }
        }
    }
}
