
using System;
using SmartHome.Controllers;
using SmartHome.Services;

namespace SmartHome
{
    class Program
    {
        static void Main(string[] args)
        {
            var lightingController = new LightingController();
            var heatingController = new HeatingController();
            var weatherService = new WeatherService("your_api_key");

            // Примеры управления устройствами
            lightingController.ToggleLight("Living Room Light");
            heatingController.SetTemperature("Living Room Heater", 22);

            // Пример использования погодного сервиса
            var weather = weatherService.GetWeather("London");
            Console.WriteLine($"Current temperature in London: {weather["current"]["temp_c"]}°C");
        }
    }
}
